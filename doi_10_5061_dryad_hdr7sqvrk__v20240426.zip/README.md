# Spectral and trait data for Rapid estimates of leaf litter chemistry using reflectance spectroscopy

[https://doi.org/10.5061/dryad.hdr7sqvrk](https://doi.org/10.5061/dryad.hdr7sqvrk)

## Description of the data and file structure

This dataset contains reflectance spectra of leaf litter from the Forests and Biodiversity 1 experiment at Cedar Creek Ecosystem Science Reserve, as well as a residential property in Minneapolis. The same litter samples were measured while intact (whole) or ground (powdered). Reflectance spectra were measured with a Spectral Evolution PSR+ 3500 (Haverhill, MA, United States), using either a leaf clip (intact leaves) or a benchtop reflectance probe (ground leaves) supplied by the same company.

The two main files for intact and ground spectra (*intact_spec.csv* and *ground_spec.csv*) contain metadata (sample information and functional traits) and the spectra themselves. Each row is a sample. More context for the sample information and functional traits (including units) can be found in the *metadata_fields.csv* file; detailed measurement information can be found in the associated paper.

Columns with numerical names (400 to 2400) are wavelength bands of the reflectance spectrum. Reflectance values are expressed as the fraction of light reflected from 0 to 1, and the wavelength units are nm. Each reflectance spectrum is the average of multiple replicate measurements of a sample. The reflectance spectra have been automatically resampled to 1 nm resolution and jump-corrected in sensor overlap regions.

## Data use

The spectra and trait data together have been used to calibrate and validate a set of partial least-squares regression models used for predicting traits from spectra, found at: [https://doi.org/10.5061/dryad.hdr7sqvrg](https://doi.org/10.5061/dryad.hdr7sqvrg). The README of that repository gives an example of how to read in the data .csv files using the package `spectrolab v. 0.0.18` in `R 4.2.1`, which is copied below. In `spectrolab`, the class `spectra` allows users to attach and retrieve metadata from spectral data using the function `meta()`.

```
library(spectrolab)

spec_df<-read.csv("mydata.csv")
name_var<-1 ## index for the column that contains sample names
meta_vars<-2:20 ## adjust as needed: indices for columns that contain metadata (including traits)
band_names<-400:2400 ## wavelengths of spectral bands corresponding to remaining columns

## you can also use the as_spectra command, but it's a bit more finicky 
## with data frames because the column names of bands must contain a letter
spec<-spectra(value = spec_df[,-c(name_vars,meta_vars)],
              band_names = 400:2400,
              names = spec_df[,name_var],
              meta = spec_df[,meta_vars])
test.spectra<-as.matrix(spec)
```

## Sharing/Access information

An identical version of these data is available at EcoSIS [here](https://ecosis.org/package/intact--and-ground-leaf-litter-spectra-from-cedar-creek-and-minneapolis). Please contact Shan Kothari at shan.kothari [at] umontreal [dot] ca or quercusacerifolia [at] gmail [dot] com with any questions.
